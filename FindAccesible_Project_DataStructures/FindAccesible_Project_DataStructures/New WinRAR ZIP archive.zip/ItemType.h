#ifndef __ITEMTYPE_H
#define	__ITEMTYPE_H
#pragma warning (disable:4996)

#include "Static_List.h"

class ItemType
{
	friend class Stack;
private: // members:
	int headComputerIndex,headList,line;
//	StaticList* networkArray, *Accesible_List;
	StaticNode current_node;
	//char* colors;
public://Constructor
	ItemType() = default;
	ItemType(int headComputerIndex,int headList, const StaticNode& current_node, int line);
public://methods:
	int getLine() const;
//	int getHeadCompIndex() const;
	int getHeadList() const;
	void setLine(int line);
	void setAll(int headComputerIndex, int headList, const StaticNode& current_node, int line);
};

#endif