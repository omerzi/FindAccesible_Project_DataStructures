﻿#include "Computers_Network.h"
#define START 1
#define AFTER_FIRST 2
#define AFTER_SECOND 3
//Constructor:
ComputersNetwork::ComputersNetwork(int size)
{
	this->networkArray_size = size;
	this->networkArray = new StaticList[size+1];//+1 because we are using index 1-size
	for (int i = 0; i < size + 1; i++)
		networkArray[i].MakeEmpty(size-1); // size -1
}

ComputersNetwork::~ComputersNetwork()
{
	delete[] networkArray;
}

//Getting input from the user :
void ComputersNetwork::network_data_input()
{
	int num_of_pairs, computerIndex,computerReceiver;
	cout << "Please enter the number of pairs:" << endl;
	cin >> num_of_pairs;
	cout << "Please enter the pairs:" << endl;
	for (int i = 0; i < num_of_pairs; i++)
	{
		cin >> computerIndex;
		cin >> computerReceiver;
		this->networkArray[computerIndex].InsertAfter(computerReceiver, this->networkArray[computerIndex].getTail());
	}

}
//Find Accesible Recursive function: 
StaticList * ComputersNetwork::FindAccesible_Rec(int headComputerIndex)
{
	char* colors = new char[this->networkArray_size+1];
	StaticList * Accesible_List=new StaticList(this->networkArray_size+1);
	for (int i = 1; i < this->networkArray_size + 1; i++)
	{
		colors[i] = 'w'; //represents "white" color
	}
	//FindAccesible(headComputerIndex, this->networkArray, colors, Accesible_List);
	//Accesible_List->printList();
	FindAccesible_NotRec(headComputerIndex, this->networkArray, colors, Accesible_List);
	Accesible_List->printList();
	delete[] colors;
	return Accesible_List;
}

void ComputersNetwork::FindAccesible(int headComputerIndex, StaticList* networkArray, char* colors, StaticList* Accesible_List)
{
	int headList = networkArray[headComputerIndex].getHeadList();
	colors[headComputerIndex] = 'b';
	Accesible_List->InsertAfter(headComputerIndex, Accesible_List->getTail()); 
	StaticNode current_node = networkArray[headComputerIndex].getList()[headList];
	while (current_node.getNextNode() != -1 && headList != -1)
	{
		if (colors[current_node.getComputerNumber()] == 'w')
		{
			FindAccesible(current_node.getComputerNumber(), networkArray, colors, Accesible_List);
		}
		current_node = networkArray[headComputerIndex].getList()[current_node.getNextNode()];
	}
	if (current_node.getNextNode() == -1) // case for the last element in the list
	{
		if (colors[current_node.getComputerNumber()] == 'w')
		{
			FindAccesible(current_node.getComputerNumber(), networkArray, colors, Accesible_List);
		}
	}
}

void ComputersNetwork::FindAccesible_NotRec(int headComputerIndex, StaticList* networkArray, char* colors, StaticList* Accesible_List)
{
	Stack stack;
	int headList = networkArray[headComputerIndex].getHeadList();
	StaticNode current_node = networkArray[headComputerIndex].getList()[headList];
	ItemType current(headComputerIndex, headList, current_node, START);
	ItemType next;
	stack.Push(current);
	while (!stack.isEmpty())
	{
		current = stack.Pop();
		if (current.getLine() == START)
		{
			colors[headComputerIndex] = 'b';
			Accesible_List->InsertAfter(headComputerIndex, Accesible_List->getTail());
			if (current_node.getNextNode() == -1) // case for the last element in the list
				{
					if (colors[current_node.getComputerNumber()] == 'w')
					{
						headComputerIndex = current_node.getComputerNumber();
						current.setLine(AFTER_FIRST);
						stack.Push(current);
						current_node = networkArray[headComputerIndex].getList()[headList];
						headList = networkArray[headComputerIndex].getHeadList();
						next.setAll(headComputerIndex, headList, current_node, START);
						stack.Push(next); 
					}
				}
		}
		else if (current.getLine() == AFTER_FIRST)
		{
			headComputerIndex = current_node.getComputerNumber();
			current.setLine(AFTER_SECOND);
			stack.Push(current);
			headList = networkArray[headComputerIndex].getHeadList();
			current_node = networkArray[headComputerIndex].getList()[headList];
			next.setAll(headComputerIndex, headList, current_node, START);
			stack.Push(next);
		}
		else if (current.getLine() == AFTER_SECOND)
		{
			//DO NOTHING
		}

		//Curr = S.Pop();
		//if (Curr.line == START) {
		//	if (Curr.n == 1)
		//		cout << “Move disk 1 from” << Curr.from << “to” << Curr.to << “\n”;
		//	else {
		//		Curr.line = AFTER_FIRST;
		//		S.Push(Curr);
		//		Next = (Curr.n  1, Curr.from, Curr.using, Curr.to, START);
		//		S.Push(Next);
		//	}
		//}
		//else if (Curr.line == AFTER_FIRST) {
		//	cout << “Move disk” << Curr.n << “from” << Curr.from << “to” << Curr.to << “\n”;
		//	Curr.line = AFTER_SECOND;
		//	S.Push(Curr);
		//	Next = (Curr.n  1, Curr.using, Curr.to, Curr.from, START);
		//	S.Push(Next);
		//}
		//else if (Curr.line == AFTER_SECOND) {
		//	// In this case do nothing.
		//}
	}
	Accesible_List->printList();
	cout << endl;
}
