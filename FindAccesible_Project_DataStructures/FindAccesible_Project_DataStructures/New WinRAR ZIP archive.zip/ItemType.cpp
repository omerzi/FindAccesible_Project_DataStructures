#include "ItemType.h"

ItemType::ItemType(int headComputerIndex, int headList, const StaticNode& current_node, int line)
{
//	(int headComputerIndex, StaticList * networkArray, char* colors, StaticList * Accesible_List, int headList, const StaticNode & current_node, int line)
	this->headComputerIndex = headComputerIndex;
//	this->networkArray = networkArray;
	//this->colors = colors;
	//this->Accesible_List = Accesible_List;
	this->headList = headList;
	this->current_node = current_node;
	this->line = line;
}

int ItemType::getLine() const
{
	return this->line;
}

//int ItemType::getHeadCompIndex() const
//{
//	return this->getHeadCompIndex;
//}

int ItemType::getHeadList() const
{
	return this->headList;
}

void ItemType::setLine(int line)
{
	this->line = line;
}

void ItemType::setAll(int headComputerIndex, int headList, const StaticNode& current_node, int line)
{
	this->headComputerIndex = headComputerIndex;
	this->headList = headList;
	this->current_node = current_node;
	this->line = line;
}
